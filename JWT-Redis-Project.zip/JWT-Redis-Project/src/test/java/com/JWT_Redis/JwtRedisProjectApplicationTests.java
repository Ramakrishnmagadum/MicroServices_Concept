package com.JWT_Redis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtRedisProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
