package com.JWT_Redis.config;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.JWT_Redis.config.Exception.InvalidTokenException;
import com.JWT_Redis.service.CustomUserDetailsService;
import com.JWT_Redis.service.JwtService;
import com.JWT_Redis.service.TokenBlacklistService;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

	@Autowired
	JwtService jwtService;

	@Autowired
	TokenBlacklistService blackListService;

	@Autowired
	CustomUserDetailsService userDetailsService;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		String header = request.getHeader("Authorization");
		if (header == null || !header.startsWith("Bearer")) {
			filterChain.doFilter(request, response);
			return;
		}
		String token = header.substring(7);
		System.out.println("JWT  Token " + token);
		try {
			String username = jwtService.extractUsername(token);
//			String role = jwtService.extractRole(token);
			String JwtID = jwtService.extractJWTID(token);

			if (blackListService.IsblackListed(JwtID)) {
				System.out.println("JWT is blackListed");
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				response.getWriter().write("Token has been revoked");
				return;
			}
			UserDetails userDetails = userDetailsService.loadUserByUsername(username);
			UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
					userDetails, null, userDetails.getAuthorities());
			SecurityContextHolder.getContext().setAuthentication(authenticationToken);

			filterChain.doFilter(request, response);
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus(401);
			response.getWriter().write("Invalid or expired token");
			throw new InvalidTokenException("JWT Token is Invalide " + e.getMessage());
		}

		filterChain.doFilter(request, response);
	}
}