package com.JWT_Redis.service;

import java.time.Duration;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class TokenBlacklistService {

	private final StringRedisTemplate redisTemplate;

	public TokenBlacklistService(StringRedisTemplate redisTemplate) {
		this.redisTemplate = redisTemplate;
	}

	public void blackListAccessToken(String JwtID, long remainingTime) {
		String key = "blacklist:" + JwtID;
		redisTemplate.opsForValue().set(key, "true", Duration.ofMillis(remainingTime));
	}

	public boolean IsblackListed(String JwtID) {
		String key = "blacklist:" + JwtID;
		return Boolean.TRUE.equals(redisTemplate.hasKey(key));
	}
}
