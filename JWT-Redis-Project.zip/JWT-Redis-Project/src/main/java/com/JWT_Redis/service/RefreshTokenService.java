package com.JWT_Redis.service;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class RefreshTokenService {

	private final StringRedisTemplate redisTemplate;
	private final long refreshTokenExpiration;

	public RefreshTokenService(StringRedisTemplate redisTemplate,
			@Value("${refresh.expiration}") long refreshTokenExpiration) {
		this.redisTemplate = redisTemplate;
		this.refreshTokenExpiration = refreshTokenExpiration;
	}

	public String createRefreshToken(String username) {
		String refreshToken = UUID.randomUUID().toString();

		String key = "refresh_token:" + refreshToken;

		redisTemplate.opsForValue().set(key, username, refreshTokenExpiration);
		return refreshToken;
	}

	public String getUsername(String refreshToken) {
		String key = "refresh_token:" + refreshToken;
		return redisTemplate.opsForValue().get(key);
	}

	public Boolean deleteToken(String refreshToken) {
		String key = "refresh_token:" + refreshToken;
		return redisTemplate.delete(key);
	}
}