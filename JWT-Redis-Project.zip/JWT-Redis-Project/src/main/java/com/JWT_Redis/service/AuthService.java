package com.JWT_Redis.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.JWT_Redis.Repository.UserRepository;
import com.JWT_Redis.dto.LoginResponse;
import com.JWT_Redis.dto.RefreshRequest;
import com.JWT_Redis.dto.RegisterRequest;
import com.JWT_Redis.entity.User;

@Service
public class AuthService {
	private final UserRepository userRepository;
	private final PasswordEncoder passwordEncoder;
	private final JwtService jwtService;
	private final RefreshTokenService refreshTokenService;
	private final TokenBlacklistService blacklistService;

	public AuthService(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtService jwtService,
			RefreshTokenService refreshTokenService, TokenBlacklistService blacklistService) {
		this.userRepository = userRepository;
		this.passwordEncoder = passwordEncoder;
		this.jwtService = jwtService;
		this.refreshTokenService = refreshTokenService;
		this.blacklistService = blacklistService;
	}

	public void registerUser(RegisterRequest request) {
		if (userRepository.findByUsername(request.getUsername()).isPresent()) {
			throw new RuntimeException("Username already present ");
		}
		User user = new User(request.getUsername(), passwordEncoder.encode(request.getPassword()), "User");
		userRepository.save(user);
	}

	public LoginResponse getAccessToken(RegisterRequest request) {
		userRepository.findByUsername(request.getUsername()).orElseThrow(() -> {
			throw new RuntimeException("Username and Password Incorrect");
		});

		User user = userRepository.findByUsername(request.getUsername()).get();
		if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
			throw new RuntimeException("Username and Password Incorrect");
		}
		String token = jwtService.getAccessToken(user.getUsername(), user.getRole());
		String refreshToken = refreshTokenService.createRefreshToken(user.getUsername());
		return new LoginResponse(token, refreshToken);
	}

	public LoginResponse refresh(RefreshRequest request) {
		String refreshToken = request.getRefreshToken();
		String username = refreshTokenService.getUsername(refreshToken);
		if (username == null) {
			throw new RuntimeException("Invalid or expired refresh token");
		}

		// Get latest user information from PostgreSQL
		User user = userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found"));

		// Refresh Token Rotation
		refreshTokenService.deleteToken(refreshToken);
		String token = jwtService.getAccessToken(user.getUsername(), user.getRole());
		refreshToken = refreshTokenService.createRefreshToken(user.getUsername());

		return new LoginResponse(token, refreshToken);
	}

	public void logout(String refreshToken, String acessToken) {
		refreshTokenService.deleteToken(refreshToken);

		String JwtID = jwtService.extractJWTID(acessToken);
		Long remainingTime = jwtService.remainingTime(acessToken);
		if (remainingTime > 0) {
			blacklistService.blackListAccessToken(JwtID, remainingTime);
		}
	}
}