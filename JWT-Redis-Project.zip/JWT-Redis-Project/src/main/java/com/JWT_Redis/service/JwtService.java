package com.JWT_Redis.service;

import java.util.Base64;
import java.util.Date;
import java.util.Random;
import java.util.UUID;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {

	private SecretKey secretKey;
	private Long expiration;

	public JwtService(@Value("${jwt.secret}") String secretKey, @Value("${jwt.expiration}") Long expiration) {
		this.secretKey = Keys.hmacShaKeyFor(Base64.getDecoder().decode(secretKey));
		this.expiration = expiration;
	}

	public String getAccessToken(String username, String role) {
		Date now = new Date();
		Date expirationDate = new Date(now.getTime() + expiration);
		String jwtID = UUID.randomUUID().toString();
		return Jwts.builder().id(jwtID).subject(username).claim("role", role).issuedAt(now).expiration(expirationDate)
				.signWith(secretKey).compact();
	}
	public String extractUsername(String token) {
		return Jwts.parser().verifyWith(secretKey).build().parseSignedClaims(token).getPayload().getSubject();
	}

	public String extractRole(String token) {
		return Jwts.parser().verifyWith(secretKey).build().parseSignedClaims(token).getPayload().get("role",
				String.class);
	}

	public String extractJWTID(String token) {
		return Jwts.parser().verifyWith(secretKey).build().parseSignedClaims(token).getPayload().getId();
	}
	
	public long remainingTime(String token) {
		return Jwts.parser().verifyWith(secretKey).build().parseSignedClaims(token).getPayload().getExpiration().getTime()-System.currentTimeMillis();
	}
}
