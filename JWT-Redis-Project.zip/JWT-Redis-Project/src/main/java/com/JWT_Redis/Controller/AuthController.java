package com.JWT_Redis.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.JWT_Redis.Repository.UserRepository;
import com.JWT_Redis.dto.LoginResponse;
import com.JWT_Redis.dto.LogoutRequest;
import com.JWT_Redis.dto.RefreshRequest;
import com.JWT_Redis.dto.RegisterRequest;
import com.JWT_Redis.entity.User;
import com.JWT_Redis.service.AuthService;
import com.JWT_Redis.service.JwtService;

@RestController
@RequestMapping("/auth")
public class AuthController {

	@Autowired
	AuthService authService;

	@Autowired
	JwtService jwtService;

	@Autowired
	UserRepository repository;

	@PostMapping("/register")
	public ResponseEntity<String> register(@RequestBody RegisterRequest registerRequest) {
		authService.registerUser(registerRequest);
		return ResponseEntity.ok().body("User Registered Successfully");
	}

	@PostMapping("/login")
	public ResponseEntity<LoginResponse> getAccessToken(@RequestBody RegisterRequest registerRequest) {
		return ResponseEntity.ok().body(authService.getAccessToken(registerRequest));
	}

	@PostMapping("/refresh")
	public ResponseEntity<LoginResponse> getRefreshToken(@RequestBody RefreshRequest refreshRequest) {
		return ResponseEntity.ok().body(authService.refresh(refreshRequest));
	}

	@PostMapping("/logout")
	public ResponseEntity<String> logout(@RequestBody LogoutRequest logoutRequest) {
		authService.logout(logoutRequest.getRefreshToken() , logoutRequest.getAccessToken());
		return ResponseEntity.ok().body("Logged out Successfully");
	}
}