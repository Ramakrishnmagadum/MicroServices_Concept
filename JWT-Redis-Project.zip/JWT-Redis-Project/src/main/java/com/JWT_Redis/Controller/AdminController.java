package com.JWT_Redis.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class AdminController {

	@GetMapping("/admin")
	public String adminAcsess() {
		return "Admin Area Accesses";
	}
}
