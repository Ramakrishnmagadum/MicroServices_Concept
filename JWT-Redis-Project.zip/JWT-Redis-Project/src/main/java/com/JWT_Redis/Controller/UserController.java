package com.JWT_Redis.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.JWT_Redis.Repository.UserRepository;
import com.JWT_Redis.entity.User;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	UserRepository userRepository;

	@GetMapping
	public ResponseEntity<User> getUser(@RequestParam("username") String username) {
		return ResponseEntity.ok().body(userRepository.findByUsername(username).get());
	}
}
