package com.JWT_Redis.dto;

public class LoginResponse {
	private String acessToken;
	private String refreshToken;

	public LoginResponse(String acessToken, String refreshToken) {
		this.acessToken = acessToken;
		this.refreshToken = refreshToken;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public String getAcessToken() {
		return acessToken;
	}

	public void setAcessToken(String acessToken) {
		this.acessToken = acessToken;
	}

}
