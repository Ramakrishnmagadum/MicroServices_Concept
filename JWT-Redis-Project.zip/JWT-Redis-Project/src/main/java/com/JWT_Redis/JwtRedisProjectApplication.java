package com.JWT_Redis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories
public class JwtRedisProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtRedisProjectApplication.class, args);
	}

}
